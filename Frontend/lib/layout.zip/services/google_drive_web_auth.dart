// lib/services/google_drive_web_auth.dart
// This implementation is for web platforms.

import 'dart:async';
import 'dart:convert';
import 'dart:html' as html; // 웹 전용 라이브러리 (dart:io 대신 사용)
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart'; // 웹에서도 사용 가능 (localStorage 기반)
import 'package:flutter_dotenv/flutter_dotenv.dart';

// 참고: flutter_secure_storage의 웹 구현은 localStorage를 사용하며,
// 민감한 데이터를 저장하는 데에는 한계가 있을 수 있습니다.
// 아주 민감한 애플리케이션의 경우, 백엔드에서 토큰을 관리하는 것을 고려하세요.
const _storage = FlutterSecureStorage();

// 팝업 창 객체를 저장하여 닫을 때 사용
html.WindowBase? _authPopup;

class GoogleDriveAuthWeb {
  final String _clientId = dotenv.env['GOOGLE_CLIENT_ID'] ?? '';
  // Client Secret은 웹 Implicit Grant 플로우에서는 필요하지 않습니다.
  // PKCE를 사용한 Code 플로우에서도 클라이언트에서는 보내지 않습니다.
  // 따라서 웹 코드에서는 사용되지 않습니다.
  // final String _clientSecret = dotenv.env['GOOGLE_CLIENT_SECRET'] ?? '';

  // 요청할 권한 범위
  final List<String> _scopes = [
    'email',
    'https://www.googleapis.com/auth/drive.readonly',
  ];

  // 웹을 위한 리디렉션 URI는 일반적으로 애플리케이션의 기본 URL 또는
  // OAuth 응답을 처리하는 특정 페이지입니다. 이 URL은 Google Cloud Console에 정확하게 설정되어야 합니다.
  // 예시: 'http://localhost:XXXX/index.html' 또는 배포된 사이트 주소
  // 여기서는 '/oauth2callback.html' 이라는 특정 경로를 사용하는 예시로 변경합니다.
  // 이 경로에 응답을 처리할 HTML 파일이 있어야 합니다.
  final String _redirectPath = '/oauth2callback.html'; // 웹 앱의 특정 경로
  late final String _redirectUri; // 앱의 origin과 결합될 최종 리디렉션 URI

  // 인증 완료 신호를 기다리기 위한 Completer (access token 또는 오류를 담을 수 있습니다)
  Completer<String>? _authCompleter;

  // 팝업 창으로부터 메시지를 받을 이벤트 리스너
  late html.EventListener _messageEventListener;

  GoogleDriveAuthWeb() {
    // 최종 리디렉션 URI 설정 (현재 앱의 origin + 설정한 경로)
    _redirectUri = html.window.location.origin + _redirectPath;
    print('[GoogleDriveAuthWeb] Redirect URI: $_redirectUri');

    // 팝업 창으로부터 메시지를 받을 리스너 설정
    _messageEventListener = (html.Event event) {
      if (event is html.MessageEvent) {
        // event.origin은 메시지를 보낸 창의 출처를 나타냅니다. 보안을 위해 확인하는 것이 좋습니다.
        // event.data는 팝업에서 보낸 데이터입니다. (예: URL fragment 또는 query string)
        print('Received message from origin: ${event.origin}');
        print('Received message data: ${event.data}');

        final data = event.data;

        // 데이터가 문자열이고 # 또는 ? 로 시작하는 경우 (OAuth 응답 URL 형식)
        if (data is String && (data.startsWith('#') || data.startsWith('?'))) {
          try {
            // Fragment (#) 또는 Query String (?)을 파싱합니다.
            final uri = Uri.parse(
              'http://dummy.com/' + data,
            ); // 파싱을 위해 임의의 base URL 추가
            final params =
                data.startsWith('#')
                    ? Uri.splitQueryString(uri.fragment)
                    : uri.queryParameters;

            final accessToken = params['access_token'];
            final error = params['error'];
            // TODO: 'expires_in' 등 다른 파라미터도 처리하고 저장해야 합니다.

            if (accessToken != null) {
              print('[GoogleDriveAuthWeb] Access Token Received');
              _handleTokenReceived(accessToken);
              // Completer가 아직 완료되지 않았다면 완료합니다.
              if (_authCompleter != null && !_authCompleter!.isCompleted) {
                _authCompleter?.complete(accessToken);
              }
            } else if (error != null) {
              print('[GoogleDriveAuthWeb] OAuth Error Received: $error');
              if (_authCompleter != null && !_authCompleter!.isCompleted) {
                _authCompleter?.completeError(Exception('OAuth error: $error'));
              }
            } else {
              // access_token도 없고 error도 없는 경우 (Code Flow에서 코드를 받은 경우 등)
              final code = params['code'];
              if (code != null) {
                // Authorization Code Flow (PKCE 필요) - 여기서 코드를 받으면 토큰 교환 API를 호출해야 합니다.
                print(
                  '[GoogleDriveAuthWeb] Authorization code received: $code. Token exchange needed.',
                );
                // TODO: Implement exchanging the code for tokens using the /token endpoint
                // 이 예시에서는 Implicit Grant를 사용하므로 이 경로는 일반적으로 발생하지 않습니다.
                if (_authCompleter != null && !_authCompleter!.isCompleted) {
                  _authCompleter?.completeError(
                    UnimplementedError(
                      'Authorization Code flow token exchange not fully implemented yet. Code: $code',
                    ),
                  );
                }
              } else {
                // 예상치 못한 응답 형식
                print(
                  '[GoogleDriveAuthWeb] Unexpected OAuth response format: $data',
                );
                if (_authCompleter != null && !_authCompleter!.isCompleted) {
                  _authCompleter?.completeError(
                    Exception('Unexpected OAuth response format'),
                  );
                }
              }
            }
          } catch (e) {
            print(
              '[GoogleDriveAuthWeb] Error parsing OAuth response message: $e',
            );
            if (_authCompleter != null && !_authCompleter!.isCompleted) {
              _authCompleter?.completeError(
                Exception('Error processing OAuth response: $e'),
              );
            }
          } finally {
            // 메시지 처리 후 팝업 창 닫기
            _authPopup?.close();
            _authPopup = null;
            // 리스너 제거 (중복 처리 방지 및 정리)
            html.window.removeEventListener('message', _messageEventListener);
          }
        } else {
          print(
            '[GoogleDriveAuthWeb] Received non-OAuth message format: $data',
          );
          // OAuth 응답이 아닌 다른 메시지 처리 (필요시)
        }
      }
    };

    // 서비스 초기화 시 메시지 리스너 추가
    html.window.addEventListener('message', _messageEventListener);
  }

  // dispose 메서드: 위젯이 제거될 때 리스너를 해제
  void dispose() {
    print('[GoogleDriveAuthWeb] Disposing, removing message listener.');
    html.window.removeEventListener('message', _messageEventListener);
    // 만약 팝업 창이 아직 열려있다면 닫습니다.
    _authPopup?.close();
    _authPopup = null;
  }

  // Access Token 가져오기 (또는 필요시 로그인 시작)
  Future<String?> getAccessToken() async {
    // 1. 저장된 토큰 확인
    String? accessToken = await _storage.read(key: 'google_access_token');
    // TODO: 토큰 만료 시간 확인 및 refresh token 사용 로직 추가 (Code Flow 시)

    if (accessToken != null) {
      print("[GoogleDriveAuthWeb] Using saved Access Token (Web)");
      // TODO: 토큰이 여전히 유효한지 검증하는 로직 추가
      return accessToken;
    }

    // 2. 저장된 토큰이 없으면 OAuth 플로우 시작
    print(
      "[GoogleDriveAuthWeb] No saved Access Token (Web), initiating login...",
    );

    // 이미 인증 플로우가 진행 중인지 확인
    if (_authCompleter != null && !_authCompleter!.isCompleted) {
      print("[GoogleDriveAuthWeb] Auth flow already in progress.");
      // 이미 진행 중인 플로우의 결과를 기다리거나, 새 요청 오류 처리
      return _authCompleter!.future.catchError((e) {
        print("[GoogleDriveAuthWeb] Waiting for existing auth flow failed: $e");
        return null; // 오류 발생 시 null 반환
      });
    }

    _authCompleter = Completer<String>(); // 새 Completer 생성

    // 웹을 위한 인증 URL 생성 (Implicit Grant 예시)
    // response_type=token을 사용하여 access token을 직접 받습니다.
    // 보안 강화를 위해 PKCE를 사용한 Authorization Code Flow (response_type=code)를 고려하세요.
    final String authUrl =
        'https://accounts.google.com/o/oauth2/v2/auth?' +
        'client_id=$_clientId&' +
        'redirect_uri=${Uri.encodeComponent(_redirectUri)}&' + // 설정된 리디렉션 URI 사용
        'response_type=token&' + // Implicit Grant
        'scope=${Uri.encodeComponent(_scopes.join(' '))}&' +
        'include_granted_scopes=true';
    // 'state=YOUR_RANDOM_STATE_STRING'; // 선택 사항: 보안을 위한 state 파라미터 포함

    // Google 로그인 플로우를 위한 새 팝업 창 열기
    _authPopup = html.window.open(
      authUrl,
      'GoogleSignIn', // 창 이름 (고유해야 새 창이 열림)
      'width=500,height=600,resizable=yes,scrollbars=yes', // 창 속성
    );

    // 팝업 차단 시 null일 수 있음
    if (_authPopup == null) {
      print(
        "[GoogleDriveAuthWeb] Failed to open popup window. Popup blockers might be enabled.",
      );
      _authCompleter?.completeError(
        Exception("팝업 창을 열 수 없습니다. 팝업 차단을 해제해주세요."),
      );
      return null;
    }

    // 팝업 창이 닫혔는지 주기적으로 확인 (사용자가 수동으로 닫았을 경우 처리)
    Timer? popupCheckTimer;
    popupCheckTimer = Timer.periodic(const Duration(milliseconds: 500), (
      timer,
    ) {
      // 팝업 창이 존재하고 닫혔으면
      if (_authPopup != null && _authPopup!.closed!) {
        timer.cancel(); // 타이머 중지
        print("[GoogleDriveAuthWeb] Popup window was closed by user.");
        // Completer가 아직 완료되지 않았다면 오류로 완료
        if (_authCompleter != null && !_authCompleter!.isCompleted) {
          _authCompleter!.completeError(Exception("인증 창이 닫혔습니다."));
        }
        _authPopup = null; // 팝업 객체 해제
        html.window.removeEventListener(
          'message',
          _messageEventListener,
        ); // 리스너 해제
      }
      // Completer가 완료되면 타이머 중지 (메시지 수신 또는 오류 발생 시)
      if (_authCompleter != null && _authCompleter!.isCompleted) {
        timer.cancel();
        _authPopup = null; // Completer 완료 후 팝업이 안 닫혔다면 강제 해제 (리스너에서 닫는 것이 기본)
      }
    });

    // 팝업에서 토큰을 포함한 메시지가 올 때까지 대기
    try {
      final token = await _authCompleter!.future;
      return token;
    } catch (e) {
      print("[GoogleDriveAuthWeb] Web auth flow failed: $e");
      // 대기 중 오류 발생 시 팝업이 안 닫혔다면 닫기
      _authPopup?.close();
      _authPopup = null;
      html.window.removeEventListener(
        'message',
        _messageEventListener,
      ); // 리스너 해제
      return null;
    } finally {
      // 어떤 경우든 완료되면 (성공 또는 실패), 타이머가 실행 중이면 중지
      popupCheckTimer?.cancel();
    }
  }

  // OAuth 플로우로부터 access token을 받았을 때 호출됨
  void _handleTokenReceived(String accessToken) {
    print("[GoogleDriveAuthWeb] Access Token received and saved (Web)");
    // Access token 저장 (Implicit Grant의 경우 refresh token은 없습니다)
    // TODO: 만료 시간(expires_in)도 함께 저장하여 만료 전에 갱신하도록 관리
    _storage.write(key: 'google_access_token', value: accessToken);
  }

  // Refresh Access Token
  // 웹 Implicit Grant 플로우에서는 refresh token이 발급되지 않으므로 갱신이 불가능합니다.
  // PKCE를 사용한 Authorization Code Flow를 사용해야 refresh token을 얻고 갱신할 수 있습니다.
  Future<String?> refreshAccessToken() async {
    print(
      "[GoogleDriveAuthWeb] Refresh Token is not available with Web Implicit Grant flow.",
    );
    // TODO: PKCE를 사용한 Authorization Code Flow 시 갱신 로직 구현
    // 필요하다면 자동으로 다시 getAccessToken을 호출하여 재인증을 시도할 수 있습니다.
    return null;
  }

  // 로그아웃 (저장된 토큰 삭제)
  Future<void> logout() async {
    print("[GoogleDriveAuthWeb] Logging out (Web): Clearing stored tokens.");
    await _storage.delete(key: 'google_access_token');
    await _storage.delete(key: 'google_refresh_token'); // 저장했다면 이것도 삭제
    // Google 세션 자체에서 로그아웃하려면 Google Sign-Out API를 호출해야 합니다.
    // https://developers.google.com/identity/protocols/oauth2/web-server#tokenrevoke
    // 또는 브라우저의 쿠키를 지우는 등의 추가 작업이 필요할 수 있습니다.
  }

  // 위젯dispose 시 호출되어 리스너를 해제해야 합니다.
  // 이 클래스의 인스턴스를 상태full 위젯의 State 객체에 유지하고 dispose에서 호출하는 방식이 일반적입니다.
}
